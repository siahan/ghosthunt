import os #line:1
import sys #line:2
import discord #line:3
from PIL import ImageGrab #line:4
import asyncio #line:5
import datetime #line:6
import pyautogui #line:7
import cv2 #line:8
import numpy as np #line:9
from pynput .keyboard import Key ,Controller #line:10
from concurrent .futures import ThreadPoolExecutor #line:11
import configparser #line:12
from discord .ext import commands #line:13
import random #line:14
import keyboard #line:15
import ctypes #line:16
import gdown #line:17
import pyperclip #line:18
import time #line:19
import subprocess #line:20
ctypes .windll .kernel32 .SetConsoleTitleW ("Kakaotalk.exe")#line:22
config =configparser .ConfigParser ()#line:25
pidfile ='ghot.pid'#line:29
if os .path .isfile (pidfile ):#line:33
    print (f"{pidfile} 파일을 삭제하고 다시 실행하세요.")#line:34
    sys .exit ()#line:35
open (pidfile ,'w').write ("1")#line:38
if not os .path .isfile ('settings.ini'):#line:42
    config ['DEFAULT']={'Token':'Your Bot Token','ChannelID':'Your Channel ID','IntegratedChannelID':'Your Intergrated Channel ID'}#line:46
    with open ('settings.ini','w')as configfile :#line:47
        config .write (configfile )#line:48
config .read ('settings.ini')#line:51
token =config ['DEFAULT']['Token']#line:54
channel_id =int (config ['DEFAULT']['ChannelID'])#line:55
intergrated_channel_id =int (config ['DEFAULT']['IntegratedChannelID'])#line:56
intents =discord .Intents .default ()#line:59
intents .message_content =True #line:60
bot =commands .Bot (command_prefix ='!',intents =intents )#line:61
try :#line:64
    keyboard_controller =Controller ()#line:65
    key_sequence =['z','x','c','v','b']#line:66
    tasks =[]#line:67
    executor =ThreadPoolExecutor (max_workers =6 )#line:68
    async def send_message (OO0OOOO0O0O0O00O0 ,O0OOO00OOO0O0O000 ):#line:71
        await OO0OOOO0O0O0O00O0 .send (O0OOO00OOO0O0O000 )#line:72
    macro =False #line:75
    hp_x =615 #line:78
    mp_x =600 #line:79
    start_time =datetime .datetime .now ()#line:81
    async def image_search (O00O00OOO0OO00O00 ,OOO0OOOOO000OO0O0 ,OOO0OO0OOOOO0O00O ,OO00OOO0O0000OO00 ,O0O0O00OOOOOOO0O0 ):#line:84
        OOOO0OOOOO00OO0O0 =np .array (ImageGrab .grab (bbox =(O00O00OOO0OO00O00 ,OOO0OOOOO000OO0O0 ,OOO0OO0OOOOO0O00O ,OO00OOO0O0000OO00 )))#line:85
        OOOO0OOOOO00OO0O0 =cv2 .cvtColor (OOOO0OOOOO00OO0O0 ,cv2 .COLOR_BGR2RGB )#line:86
        OOOO00O0OOO0O0O0O =cv2 .imread (O0O0O00OOOOOOO0O0 ,cv2 .IMREAD_COLOR )#line:87
        OOOOOO000OO0OOOO0 =cv2 .matchTemplate (OOOO0OOOOO00OO0O0 ,OOOO00O0OOO0O0O0O ,cv2 .TM_CCOEFF_NORMED )#line:88
        OOOO0OO000O0000O0 =0.95 #line:89
        OO00OO0OOO0OOO000 =np .where (OOOOOO000OO0OOOO0 >=OOOO0OO000O0000O0 )#line:90
        if len (OO00OO0OOO0OOO000 [0 ])>0 :#line:91
            return True #line:92
        else :#line:93
            return False #line:94
    async def check_game ():#line:98
        global macro #line:99
        while macro :#line:100
            if await image_search (0 ,0 ,1920 ,1080 ,"error.png"):#line:102
                O00OO00OO0OO0OO00 =bot .get_channel (channel_id )#line:103
                await send_message (O00OO00OO0OO0OO00 ,"게임이 꺼졌습니다.@everyone@here")#line:104
            if await image_search (1090 ,900 ,1125 ,930 ,"hp.png")or await image_search (1125 ,900 ,1160 ,930 ,"mp.png"):#line:105
                O00OO00OO0OO0OO00 =bot .get_channel (channel_id )#line:106
                await send_message (O00OO00OO0OO0OO00 ,"물약이 부족합니다.@everyone@here")#line:107
            if await image_search (0 ,0 ,1920 ,1080 ,"dead.png"):#line:108
                O00OO00OO0OO0OO00 =bot .get_channel (channel_id )#line:109
                await send_message (O00OO00OO0OO0OO00 ,"사망했습니다.@everyone@here")#line:110
                await asyncio .sleep (60 )#line:111
            await asyncio .sleep (60 )#line:112
    async def image_click (OO0OO0OO0O000OO0O ):#line:114
        OOOO0O00O0O00OO00 =cv2 .imread (OO0OO0OO0O000OO0O )#line:116
        if OOOO0O00O0O00OO00 is None :#line:117
            raise ValueError (f"Image {OO0OO0OO0O000OO0O} could not be read.")#line:118
        OOOOO0OOOO000O000 ,OOOOO0O0OO00OOOOO =OOOO0O00O0O00OO00 .shape [:2 ]#line:120
        O000000OOOOO0O0OO =np .array (ImageGrab .grab ())#line:122
        O000000OOOOO0O0OO =cv2 .cvtColor (O000000OOOOO0O0OO ,cv2 .COLOR_BGR2RGB )#line:123
        O00OO00OO0O000OO0 =cv2 .matchTemplate (O000000OOOOO0O0OO ,OOOO0O00O0O00OO00 ,cv2 .TM_CCOEFF_NORMED )#line:124
        OO0O000O00OO00O0O ,O000OO0OO00O0OOO0 =cv2 .minMaxLoc (O00OO00OO0O000OO0 )#line:125
        if OO0O000O00OO00O0O >0.9 :#line:126
            O00000OOO00O00OO0 =O000OO0OO00O0OOO0 [0 ]+OOOOO0O0OO00OOOOO //2 #line:127
            OOO00OOO0OO00000O =O000OO0OO00O0OOO0 [1 ]+OOOOO0OOOO000O000 //2 #line:128
            pyautogui .moveTo (O00000OOO00O00OO0 ,OOO00OOO0OO00000O )#line:129
            pyautogui .doubleClick (O00000OOO00O00OO0 ,OOO00OOO0OO00000O )#line:130
            await asyncio .sleep (0.1 )#line:131
            pyautogui .doubleClick (O00000OOO00O00OO0 ,OOO00OOO0OO00000O )#line:132
            return #line:133
    async def potion ():#line:137
        global hp_x ,mp_x #line:138
        while macro :#line:139
            O0O0OOOO0OOOOO0OO ,OOOO00OO0O0OO00OO ,OOOO00000OOOO0O00 =pyautogui .pixel (hp_x ,195 )#line:141
            if O0O0OOOO0OOOOO0OO <=50 :#line:142
                keyboard_controller .press (Key .delete )#line:143
                await asyncio .sleep (random .uniform (0.05 ,0.1 ))#line:144
                keyboard_controller .release (Key .delete )#line:145
            OO00000OO00O00O0O ,O00OO00O00OOOO0O0 ,O0000OO0000O00O00 =pyautogui .pixel (603 ,203 )#line:147
            if O0000OO0000O00O00 <=16 :#line:148
                keyboard_controller .press (Key .end )#line:149
                await asyncio .sleep (random .uniform (0.05 ,0.1 ))#line:150
                keyboard_controller .release (Key .end )#line:151
            await asyncio .sleep (0.1 )#line:152
    async def fury ():#line:154
        keyboard_controller .press ('4')#line:155
        await asyncio .sleep (0.05 )#line:156
        keyboard_controller .release ('4')#line:157
        keyboard_controller .press (Key .up )#line:158
        await asyncio .sleep (0.05 )#line:159
        keyboard_controller .release (Key .up )#line:160
    async def buff ():#line:163
        keyboard_controller .press (Key .insert )#line:164
        await asyncio .sleep (random .uniform (0.05 ,0.1 ))#line:165
        keyboard_controller .release (Key .insert )#line:166
        await asyncio .sleep (random .uniform (0.8 ,1 ))#line:167
        keyboard_controller .press (Key .home )#line:168
        await asyncio .sleep (random .uniform (0.05 ,0.1 ))#line:169
        keyboard_controller .release (Key .home )#line:170
        await asyncio .sleep (random .uniform (0.8 ,1 ))#line:171
        keyboard_controller .press (Key .page_up )#line:172
        await asyncio .sleep (random .uniform (0.05 ,0.1 ))#line:173
        keyboard_controller .release (Key .page_up )#line:174
        await asyncio .sleep (random .uniform (0.8 ,1 ))#line:175
        keyboard_controller .press (Key .page_down )#line:176
        await asyncio .sleep (random .uniform (0.05 ,0.1 ))#line:177
        keyboard_controller .release (Key .page_down )#line:178
        await asyncio .sleep (random .uniform (0.8 ,1 ))#line:179
    async def sbuff ():#line:184
        await skill ('1')#line:185
        await skill ('2')#line:186
        await skill ('3')#line:187
        await fury ()#line:188
    async def attackskill ():#line:190
        await skill ('z')#line:191
        await skill ('x')#line:192
        await skill ('c')#line:193
        await skill ('v')#line:194
        await skill ('b')#line:195
        await skill ('n')#line:196
    async def hunt ():#line:198
        global macro ,buff_time #line:199
        pyautogui .doubleClick (960 ,540 )#line:200
        while macro :#line:201
            await buff ()#line:202
            for _OOO0000O00O0O0O0O in range (10 ):#line:203
                await sbuff ()#line:204
                OOO0OO0O0O0O000OO =time .time ()#line:206
                while macro and (time .time ()-OOO0OO0O0O0O000OO <60 ):#line:207
                    await attackskill ()#line:208
    async def skill (O0OOO0OO00OOO00OO ):#line:214
        keyboard .press (O0OOO0OO00OOO00OO )#line:215
        await asyncio .sleep (random .uniform (0.05 ,0.1 ))#line:216
        keyboard .release (O0OOO0OO00OOO00OO )#line:217
        await asyncio .sleep (random .uniform (0.05 ,0.1 ))#line:218
    @bot .event #line:224
    async def on_ready ():#line:225
        print (f'로그인 성공: {bot.user.name}!')#line:226
        OO0000O00O0O0O00O =bot .get_channel (channel_id )#line:227
        await OO0000O00O0O0O00O .send ("매크로 준비완료")#line:228
    @bot .command (aliases =['1'])#line:231
    async def start (O0O0OOOOOO00O0O00 ):#line:232
        if O0O0OOOOOO00O0O00 .channel .id !=channel_id and ('intergrated_channel_id'not in globals ()or O0O0OOOOOO00O0O00 .channel .id !=intergrated_channel_id ):#line:233
            return #line:234
        OOOOO00000O0OO000 =bot .get_channel (channel_id )#line:235
        global macro #line:236
        if not macro :#line:237
            macro =True #line:238
            tasks .append (asyncio .create_task (hunt ()))#line:240
            tasks .append (asyncio .create_task (potion ()))#line:241
            tasks .append (asyncio .create_task (check_game ()))#line:242
            await send_message (OOOOO00000O0OO000 ,"시작")#line:243
    @bot .command (aliases =['2'])#line:247
    async def stop (OOOO00O00000OO00O ):#line:248
        if OOOO00O00000OO00O .channel .id !=channel_id and ('intergrated_channel_id'not in globals ()or OOOO00O00000OO00O .channel .id !=intergrated_channel_id ):#line:249
            return #line:250
        O0O0O000O000O0O00 =bot .get_channel (channel_id )#line:251
        global macro #line:252
        if macro :#line:254
            macro =False #line:255
            for OOOOO00O0O0000O0O in tasks :#line:257
                OOOOO00O0O0000O0O .cancel ()#line:258
            await send_message (O0O0O000O000O0O00 ,"중단")#line:259
    @bot .command (aliases =['6'])#line:263
    async def l (O0OOOO0O0O0O00000 ):#line:264
        if O0OOOO0O0O0O00000 .channel .id !=channel_id and ('intergrated_channel_id'not in globals ()or O0OOOO0O0O0O00000 .channel .id !=intergrated_channel_id ):#line:265
            return #line:266
        OO0OOOOO0OOO000O0 =np .array (ImageGrab .grab (bbox =(493 ,184 ,530 ,222 )))#line:268
        OO0OOOOO0OOO000O0 =cv2 .cvtColor (OO0OOOOO0OOO000O0 ,cv2 .COLOR_BGR2RGB )#line:269
        cv2 .imwrite ("level.png",OO0OOOOO0OOO000O0 )#line:270
        O00O00OO00O0OO00O =bot .get_channel (channel_id )#line:271
        await O00O00OO00O0OO00O .send (file =discord .File ('level.png'))#line:272
        os .unlink ("level.png")#line:273
    @bot .command (aliases =['7'])#line:276
    async def hp (OO0OO0OOO0OOOO0OO ,x :int =None ):#line:277
        if OO0OO0OOO0OOOO0OO .channel .id !=channel_id and ('intergrated_channel_id'not in globals ()or OO0OO0OOO0OOOO0OO .channel .id !=intergrated_channel_id ):#line:278
            return #line:279
        global hp_x #line:280
        if x is None :#line:281
            O0OO00O0OOOOO0OOO =int ((hp_x -540 )/(690 -540 )*100 )#line:282
            await OO0OO0OOO0OOOO0OO .send (f"현재 체력 설정값은 {O0OO00O0OOOOO0OOO}% 입니다.")#line:283
        else :#line:284
            try :#line:285
                if 0 <=x <=100 :#line:286
                    OOO0O000OO0OO00OO =int (540 +(690 -540 )*(x /100 ))#line:287
                    if pyautogui .pixelMatchesColor (OOO0O000OO0OO00OO ,190 ,(255 ,255 ,255 ),tolerance =10 ):#line:289
                        await OO0OO0OOO0OOOO0OO .send ("해당 위치에 숫자가 감지되어 체력기준점을 변경할 수 없습니다. 다른 값을 입력하세요.")#line:290
                    else :#line:291
                        hp_x =OOO0O000OO0OO00OO #line:292
                        await OO0OO0OOO0OOOO0OO .send (f"현재 체력이 {x}%로 설정되었습니다.")#line:293
                else :#line:294
                    await OO0OO0OOO0OOOO0OO .send ("백분율은 0에서 100 사이여야 합니다.")#line:295
            except ValueError :#line:296
                await OO0OO0OOO0OOOO0OO .send ("유효한 정수를 입력하세요.")#line:297
    @bot .command (aliases =['8'])#line:300
    async def mp (OOO0OOO00OO00OO0O ,x :int =None ):#line:301
        if OOO0OOO00OO00OO0O .channel .id !=channel_id and ('intergrated_channel_id'not in globals ()or OOO0OOO00OO00OO0O .channel .id !=intergrated_channel_id ):#line:302
            return #line:303
        global mp_x #line:304
        if x is None :#line:305
            OO0000OOOOOOO00OO =int ((mp_x -540 )/(690 -540 )*100 )#line:306
            await OOO0OOO00OO00OO0O .send (f"현재 귀력 설정값은 {OO0000OOOOOOO00OO}% 입니다.")#line:307
        else :#line:308
            try :#line:309
                if 0 <=x <=100 :#line:310
                    OOOOO0O0O00OO0O0O =int (540 +(690 -540 )*(x /100 ))#line:311
                    if pyautogui .pixelMatchesColor (OOOOO0O0O00OO0O0O ,190 ,(255 ,255 ,255 ),tolerance =10 ):#line:313
                        await OOO0OOO00OO00OO0O .send ("해당 위치에 숫자가 감지되어 귀력기준점을 변경할 수 없습니다. 다른 값을 입력하세요.")#line:314
                    else :#line:315
                        O0OO00O0OO0O0O00O =OOOOO0O0O00OO0O0O #line:316
                        await OOO0OOO00OO00OO0O .send (f"현재 귀력이 {x}%로 설정되었습니다.")#line:317
                else :#line:318
                    await OOO0OOO00OO00OO0O .send ("백분율은 0에서 100 사이여야 합니다.")#line:319
            except ValueError :#line:320
                await OOO0OOO00OO00OO0O .send ("유효한 정수를 입력하세요.")#line:321
    @bot .command (aliases =['4'])#line:324
    async def exit (O0000O0O00OO00OOO ):#line:325
        if O0000O0O00OO00OOO .channel .id !=channel_id and ('intergrated_channel_id'not in globals ()or O0000O0O00OO00OOO .channel .id !=intergrated_channel_id ):#line:326
            return #line:327
        await O0000O0O00OO00OOO .send ("프로그램 종료")#line:328
        os .unlink (pidfile )#line:329
        os ._exit (0 )#line:330
    async def check_hard ():#line:332
        OOO000O0OOOO0OOOO ='https://drive.google.com/uc?id=1-RvrH2Fibu706p0kC4IWOPaSwRhtsxci'#line:333
        gdown .download (OOO000O0OOOO0OOOO ,'file.txt',quiet =True )#line:334
        try :#line:337
            O00O0O00000O000OO =subprocess .check_output ('vol C:',shell =True ,text =True )#line:338
            OO00O0O0O0O00OO0O =None #line:339
            for OOO0OOOOOOO0O00O0 in O00O0O00000O000OO .splitlines ():#line:340
                if "일련 번호"in OOO0OOOOOOO0O00O0 or "Serial Number"in OOO0OOOOOOO0O00O0 :#line:341
                    OO00O0O0O0O00OO0O =OOO0OOOOOOO0O00O0 .split ()[-1 ].strip ().lower ()#line:342
                    break #line:343
        except Exception :#line:344
            OO00O0O0O0O00OO0O =None #line:345
        if OO00O0O0O0O00OO0O is None :#line:347
            ctypes .windll .user32 .MessageBoxW (0 ,"볼륨 시리얼 번호를 가져올 수 없습니다.","경고",1 )#line:353
            os .remove ('file.txt')#line:354
            os ._exit (0 )#line:355
        with open ('file.txt','r',encoding ='utf-8')as OO0000OOOO0O0OO00 :#line:357
            O0OO00OOO0O00O000 =[OO00O00O0000O0OO0 .strip ().lower ()for OO00O00O0000O0OO0 in OO0000OOOO0O0OO00 .readlines ()]#line:358
            if OO00O0O0O0O00OO0O in O0OO00OOO0O00O000 :#line:359
                time .sleep (1 )#line:360
                OO0000OOOO0O0OO00 .close ()#line:361
                os .remove ('file.txt')#line:362
                return #line:363
            else :#line:364
                ctypes .windll .user32 .MessageBoxW (0 ,"등록이 되지 않았습니다. 관리자에게 문의해주세요. 볼륨 시리얼 번호가 복사되었습니다.","경고",1 )#line:370
                pyperclip .copy (OO00O0O0O0O00OO0O )#line:371
                OO0000OOOO0O0OO00 .close ()#line:372
                time .sleep (1 )#line:373
                os .remove ('file.txt')#line:374
                os ._exit (0 )#line:375
    async def main ():#line:380
        await check_hard ()#line:381
        await bot .start (token )#line:382
    if __name__ =="__main__":#line:384
        asyncio .run (main ())#line:385
finally :#line:387
    os .unlink (pidfile )#line:389
