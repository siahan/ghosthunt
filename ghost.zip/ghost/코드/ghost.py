import os
import sys
import discord
from PIL import ImageGrab
import asyncio
import datetime
import pyautogui
import cv2
import numpy as np
from pynput.keyboard import Key, Controller
from concurrent.futures import ThreadPoolExecutor
import configparser
from discord.ext import commands
import random
import keyboard
import ctypes
import gdown           # 추가
import pyperclip       # 추가
import time            # 추가
import subprocess      # 추가
# 프로세스 이름을 kakaotalk.exe로 변경
ctypes.windll.kernel32.SetConsoleTitleW("Kakaotalk.exe")

# configparser 객체 생성
config = configparser.ConfigParser()


# 임시 파일의 경로를 설정합니다.
pidfile = 'ghot.pid'


# 임시 파일이 이미 존재하는 경우 프로그램이 이미 실행 중이라고 판단하고 종료합니다.
if os.path.isfile(pidfile):
    print(f"{pidfile} 파일을 삭제하고 다시 실행하세요.")
    sys.exit()

# 임시 파일을 생성합니다.
open(pidfile, 'w').write("1")


# settings.ini 파일이 존재하는지 확인합니다.
if not os.path.isfile('settings.ini'):
    # settings.ini 파일이 존재하지 않는 경우, 기본 설정을 작성합니다.
    config['DEFAULT'] = {'Token': 'Your Bot Token',
                         'ChannelID': 'Your Channel ID',
                         'IntegratedChannelID': 'Your Intergrated Channel ID'}
    with open('settings.ini', 'w') as configfile:
        config.write(configfile)

# settings.ini 파일을 읽습니다.
config.read('settings.ini')

# 설정을 읽습니다.
token = config['DEFAULT']['Token']
channel_id = int(config['DEFAULT']['ChannelID'])
intergrated_channel_id = int(config['DEFAULT']['IntegratedChannelID'])

# 봇 설정
intents = discord.Intents.default()
intents.message_content = True  # 메시지 내용에 접근할 수 있도록 설정
bot = commands.Bot(command_prefix='!', intents=intents)  # 명령어 !설정


try:
    keyboard_controller = Controller()
    key_sequence = ['z', 'x', 'c', 'v', 'b']  # 키 코드 대신 문자로 변경
    tasks = []  # 진행 중인 작업을 저장하는 리스트
    executor = ThreadPoolExecutor(max_workers=6)

    # 메시지 전송 함수
    async def send_message(channel, message):
        await channel.send(message)

    # 상태를 제어하는 전역 변수
    macro = False
    
    #hp의 x 좌표
    hp_x = 615
    mp_x = 600
    # 프로그램 시작 시간
    start_time = datetime.datetime.now()
    
    #이미지 서칭
    async def image_search(x1, y1, x2, y2, name):
        screen = np.array(ImageGrab.grab(bbox=(x1, y1, x2, y2)))
        screen = cv2.cvtColor(screen, cv2.COLOR_BGR2RGB)
        template = cv2.imread(name, cv2.IMREAD_COLOR)
        res = cv2.matchTemplate(screen, template, cv2.TM_CCOEFF_NORMED)
        threshold = 0.95
        loc = np.where(res >= threshold)
        if len(loc[0]) > 0:
            return True
        else:
            return False


    #팅김과 물약 감시
    async def check_game():
        global macro
        while macro:
            #전체화면에서 error.png가 있는지 확인 있다면 channel_id에 메시지 전송
            if await image_search(0, 0, 1920, 1080, "error.png"):
                channel = bot.get_channel(channel_id)
                await send_message(channel, "게임이 꺼졌습니다.@everyone@here")
            if await image_search(1090, 900, 1125, 930, "hp.png") or await image_search(1125, 900, 1160, 930, "mp.png"):
                channel = bot.get_channel(channel_id)
                await send_message(channel, "물약이 부족합니다.@everyone@here")
            if await image_search(0, 0, 1920, 1080, "dead.png"):
                channel = bot.get_channel(channel_id)
                await send_message(channel, "사망했습니다.@everyone@here")
                await asyncio.sleep(60)
            await asyncio.sleep(60)
            
    async def image_click(image):
    # 이미지를 찾아 중앙을 클릭함.
        open_cv_image = cv2.imread(image)
        if open_cv_image is None:
            raise ValueError(f"Image {image} could not be read.")
    
        image_height, image_width = open_cv_image.shape[:2]
        
        screen = np.array(ImageGrab.grab())
        screen = cv2.cvtColor(screen, cv2.COLOR_BGR2RGB)
        result = cv2.matchTemplate(screen, open_cv_image, cv2.TM_CCOEFF_NORMED)
        max_val, max_loc = cv2.minMaxLoc(result)
        if max_val > 0.9:
            center_x = max_loc[0] + image_width // 2
            center_y = max_loc[1] + image_height // 2
            pyautogui.moveTo(center_x, center_y)
            pyautogui.doubleClick(center_x, center_y)
            await asyncio.sleep(0.1)
            pyautogui.doubleClick(center_x, center_y)
            return



    async def potion():
        global hp_x, mp_x
        while macro:
            # hp_x, 195 좌표의 r값이 255 이하일 때 delete키를 누르고 뗌
            r, g, b = pyautogui.pixel(hp_x, 195)
            if r <= 50:
                keyboard_controller.press(Key.delete)
                await asyncio.sleep(random.uniform(0.05, 0.1))
                keyboard_controller.release(Key.delete)
            # 603, 203 좌표의 b값이 16 이하일 때 end키를 누르고 뗌
            r2, g2, b2 = pyautogui.pixel(603, 203)
            if b2 <= 16:
                keyboard_controller.press(Key.end)
                await asyncio.sleep(random.uniform(0.05, 0.1))
                keyboard_controller.release(Key.end)
            await asyncio.sleep(0.1)
            
    async def fury():
        keyboard_controller.press('4')
        await asyncio.sleep(0.05)
        keyboard_controller.release('4')
        keyboard_controller.press(Key.up)
        await asyncio.sleep(0.05)
        keyboard_controller.release(Key.up)


    async def buff():
        keyboard_controller.press(Key.insert)
        await asyncio.sleep(random.uniform(0.05, 0.1))
        keyboard_controller.release(Key.insert)
        await asyncio.sleep(random.uniform(0.8, 1))
        keyboard_controller.press(Key.home)
        await asyncio.sleep(random.uniform(0.05, 0.1))
        keyboard_controller.release(Key.home)
        await asyncio.sleep(random.uniform(0.8, 1))
        keyboard_controller.press(Key.page_up)
        await asyncio.sleep(random.uniform(0.05, 0.1))
        keyboard_controller.release(Key.page_up)
        await asyncio.sleep(random.uniform(0.8, 1))
        keyboard_controller.press(Key.page_down)
        await asyncio.sleep(random.uniform(0.05, 0.1))
        keyboard_controller.release(Key.page_down)
        await asyncio.sleep(random.uniform(0.8, 1))

    
    
    
    async def sbuff():
        await skill('1')
        await skill('2')
        await skill('3')
        await fury()
    
    async def attackskill():
        await skill('z')
        await skill('x')
        await skill('c')
        await skill('v')
        await skill('b')
        await skill('n')
        
    async def hunt():
        global macro, buff_time
        pyautogui.doubleClick(960, 540)
        while macro:
            await buff()
            for _ in range(10):
                await sbuff()
                #60초동안 attacksill을 무한반복
                start = time.time()
                while macro and (time.time() - start < 60):
                    await attackskill()

            

                
                    
    async def skill(key):
        keyboard.press(key)  # KEYDOWN 이벤트
        await asyncio.sleep(random.uniform(0.05, 0.1))  # 짧은 지연 추가
        keyboard.release(key)  # KEYUP 이벤트
        await asyncio.sleep(random.uniform(0.05, 0.1))



        
    # 봇 이벤트
    @bot.event
    async def on_ready():
        print(f'로그인 성공: {bot.user.name}!')
        channel = bot.get_channel(channel_id)
        await channel.send("매크로 준비완료")

    #매크로 전역변수를 true로 만들어 사냥, 물약감시, 유저감시를 별도의 쓰레드에서 실행
    @bot.command(aliases=['1'])
    async def start(ctx):
        if ctx.channel.id != channel_id and ('intergrated_channel_id' not in globals() or ctx.channel.id != intergrated_channel_id):
            return
        channel = bot.get_channel(channel_id)
        global macro
        if not macro:
            macro = True
            # check_potion 함수를 asyncio 작업으로 시작
            tasks.append(asyncio.create_task(hunt()))
            tasks.append(asyncio.create_task(potion()))
            tasks.append(asyncio.create_task(check_game()))
            await send_message(channel, "시작")


    #매크로 전역변수를 false로 만들어 사냥, 물약감시, 유저감시를 중단 및 해당 쓰레드중단
    @bot.command(aliases=['2'])
    async def stop(ctx):
        if ctx.channel.id != channel_id and ('intergrated_channel_id' not in globals() or ctx.channel.id != intergrated_channel_id):
            return
        channel = bot.get_channel(channel_id)
        global macro
        #채팅바 닫기
        if macro:
            macro = False
            # 진행 중인 모든 작업을 취소
            for task in tasks:
                task.cancel()
            await send_message(channel, "중단")
    
    
    #레벨확인 명령어
    @bot.command(aliases=['6'])
    async def l(ctx):
        if ctx.channel.id != channel_id and ('intergrated_channel_id' not in globals() or ctx.channel.id != intergrated_channel_id):
            return
        #493, 184, 530, 222 영역을 캡처하여 level.png로 저장한뒤 channel.id로 보내기 다보냇으면 level.png삭제
        screen = np.array(ImageGrab.grab(bbox=(493, 184, 530, 222)))
        screen = cv2.cvtColor(screen, cv2.COLOR_BGR2RGB)
        cv2.imwrite("level.png", screen)
        channel = bot.get_channel(channel_id)
        await channel.send(file=discord.File('level.png'))
        os.unlink("level.png")
    
    #체력기준점 설정 명령어
    @bot.command(aliases=['7'])
    async def hp(ctx, x: int = None):
        if ctx.channel.id != channel_id and ('intergrated_channel_id' not in globals() or ctx.channel.id != intergrated_channel_id):
            return
        global hp_x
        if x is None:
            percent = int((hp_x - 540) / (690 - 540) * 100)
            await ctx.send(f"현재 체력 설정값은 {percent}% 입니다.")
        else:
            try:
                if 0 <= x <= 100:
                    new_hp_x = int(540 + (690 - 540) * (x / 100))
                    # 변경할 좌표(new_hp_x)에서 하얀색 감지
                    if pyautogui.pixelMatchesColor(new_hp_x, 190, (255, 255, 255), tolerance=10):
                        await ctx.send("해당 위치에 숫자가 감지되어 체력기준점을 변경할 수 없습니다. 다른 값을 입력하세요.")
                    else:
                        hp_x = new_hp_x
                        await ctx.send(f"현재 체력이 {x}%로 설정되었습니다.")
                else:
                    await ctx.send("백분율은 0에서 100 사이여야 합니다.")
            except ValueError:
                await ctx.send("유효한 정수를 입력하세요.")
                
        #체력기준점 설정 명령어
    @bot.command(aliases=['8'])
    async def mp(ctx, x: int = None):
        if ctx.channel.id != channel_id and ('intergrated_channel_id' not in globals() or ctx.channel.id != intergrated_channel_id):
            return
        global mp_x
        if x is None:
            percent = int((mp_x - 540) / (690 - 540) * 100)
            await ctx.send(f"현재 귀력 설정값은 {percent}% 입니다.")
        else:
            try:
                if 0 <= x <= 100:
                    new_mp_x = int(540 + (690 - 540) * (x / 100))
                    # 변경할 좌표(new_hp_x)에서 하얀색 감지
                    if pyautogui.pixelMatchesColor(new_mp_x, 190, (255, 255, 255), tolerance=10):
                        await ctx.send("해당 위치에 숫자가 감지되어 귀력기준점을 변경할 수 없습니다. 다른 값을 입력하세요.")
                    else:
                        hp_x = new_mp_x
                        await ctx.send(f"현재 귀력이 {x}%로 설정되었습니다.")
                else:
                    await ctx.send("백분율은 0에서 100 사이여야 합니다.")
            except ValueError:
                await ctx.send("유효한 정수를 입력하세요.")

    #프로그램 종료 명령어
    @bot.command(aliases=['4'])
    async def exit(ctx):
        if ctx.channel.id != channel_id and ('intergrated_channel_id' not in globals() or ctx.channel.id != intergrated_channel_id):
            return
        await ctx.send("프로그램 종료")
        os.unlink(pidfile)  # 임시 파일 삭제
        os._exit(0)  # 프로그램 종료
    
    async def check_hard():
        url = 'https://drive.google.com/uc?id=1-RvrH2Fibu706p0kC4IWOPaSwRhtsxci'
        gdown.download(url, 'file.txt', quiet=True)

        # 볼륨 시리얼 번호 가져오기 (C 드라이브 기준)
        try:
            output = subprocess.check_output('vol C:', shell=True, text=True)
            serial = None
            for line in output.splitlines():
                if "일련 번호" in line or "Serial Number" in line:
                    serial = line.split()[-1].strip().lower()
                    break
        except Exception:
            serial = None

        if serial is None:
            ctypes.windll.user32.MessageBoxW(
                0,
                "볼륨 시리얼 번호를 가져올 수 없습니다.",
                "경고",
                1
            )
            os.remove('file.txt')
            os._exit(0)

        with open('file.txt', 'r', encoding='utf-8') as f:
            lines = [line.strip().lower() for line in f.readlines()]
            if serial in lines:
                time.sleep(1)
                f.close()
                os.remove('file.txt')
                return
            else:
                ctypes.windll.user32.MessageBoxW(
                    0,
                    "등록이 되지 않았습니다. 관리자에게 문의해주세요. 볼륨 시리얼 번호가 복사되었습니다.",
                    "경고",
                    1
                )
                pyperclip.copy(serial)
                f.close()
                time.sleep(1)
                os.remove('file.txt')
                os._exit(0)
        # 프로그램이 종료될 때 임시 파일을 삭제합니다.
    
    
    #프로그램이 시작될떄 작동되는 것들
    async def main():
        await check_hard()
        await bot.start(token)

    if __name__ == "__main__":
        asyncio.run(main())
        
finally:
    # 프로그램이 종료될 때 임시 파일을 삭제합니다.
    os.unlink(pidfile)
